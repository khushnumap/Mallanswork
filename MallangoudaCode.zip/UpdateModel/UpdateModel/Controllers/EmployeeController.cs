﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UpdateModel.Controllers
{
    public class EmployeeController : Controller
    {
        
        public ActionResult Index()
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            List<Employee> employees = businessLayerEmployee.GetAllEmployees();
            return View(employees);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            if (ModelState.IsValid)
            {
                businessLayerEmployee.AddEmployee(employee);
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            Employee employee = businessLayerEmployee.GetEmployeeById(id);
            return View(employee);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Update(int id)
        {
            Employee employee = new Employee();
            TryUpdateModel(employee);

            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            if (ModelState.IsValid)
            {
                businessLayerEmployee.UpdateEmployee(employee);
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Details(int id)
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            Employee employee = businessLayerEmployee.GetEmployeeById(id);
            return View("Details", employee);
        }

        public ActionResult Delete(int id)
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            Employee employee = businessLayerEmployee.GetEmployeeById(id);
            return View(employee);
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            DataLayerEmployee businessLayerEmployee = new DataLayerEmployee();
            businessLayerEmployee.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}
