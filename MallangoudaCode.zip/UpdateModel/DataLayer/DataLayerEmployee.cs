﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class DataLayerEmployee
    {
        public List<Employee> GetAllEmployees()
        {
            var deps = new List<Department>();
            using (SampleEntities dbContext = new SampleEntities())
            {
                List<Employee> lstEmployees = new List<Employee>();
                lstEmployees = dbContext.Employees.ToList();
                

                return lstEmployees;
            }
            
        }

        public void AddEmployee(Employee employee)
        {
            SampleEntities dbContext = new SampleEntities();
            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();
        }

        public Employee GetEmployeeById(int id)
        {
            SampleEntities dbContext = new SampleEntities();
            return dbContext.Employees.FirstOrDefault(t => t.ID == id);
        }

        public void UpdateEmployee(Employee employee)
        {
            SampleEntities dbContext = new SampleEntities();

            Employee dbEmployee = dbContext.Employees.FirstOrDefault(t => t.ID == employee.ID);
            dbEmployee.Name = employee.Name;
            dbEmployee.Gender = employee.Gender;
            dbEmployee.City = employee.City;
            dbEmployee.DateOfBirth = employee.DateOfBirth;

            dbContext.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            SampleEntities dbContext = new SampleEntities();
            Employee dbEmployee = dbContext.Employees.FirstOrDefault(t => t.ID == id);

            dbContext.Employees.Remove(dbEmployee);
            dbContext.SaveChanges();
        }
    }
}
