declare @ASL char(5)
declare @Trans_Id char(2)
set @ASL='889'
set @Trans_Id='89'


--1) Delete policies from working table which are not in SCH T 
Delete from W_DM_QER where policy_number in (
Select distinct policy_number from W_DM_QER where policy_number not in ( select [policy reference]
	from
	Policy_SCHT  	 
	where [Statement Line Name] in ('88.9') and [State Code] = 'TY'  and Report_Year=2015 and Report_Qtr=3 and
	([Loss Paid Indemnity - Chg in Period] <> 0
	or [Loss Paid Legal - Chg in Period] <>0	
	or [Loss Outstanding Indemnity - End of Period] <> 0
	or [Loss Outstanding Legal - End of Period]<> 0
	or [Premium Written - Chg in Period] <>0)
	)
	and ASL_Code = @ASL 
)
--2) updating difference values after comparing with SCH T


DECLARE @temp table
(

Sno int identity(1,1),
Policy_number varchar(30),
OutExpensesDiff int
)

insert into @temp
select Policy_Number, sum(Written_Premium) -	
(select Sum([Premium Written - Chg in Period]) from Policy_SCHT where [policy reference] = Policy_Number and Report_Year=2015 and Report_Qtr=3) 
	from  W_DM_QER 
	where ASL_Code in(@ASL)	 
	Group By Policy_Number
	having  sum(Written_Premium)
	<>  (select Sum([Premium Written - Chg in Period]) from Policy_SCHT where [policy reference] = Policy_Number and Report_Year=2015 and Report_Qtr=3)
	
DECLARE @rows int
DECLARE @loop int
DECLARE @policy varchar(30)
DECLARE @diff int
DECLARE @totalrows int
DECLARE @updatevalue decimal(15,2)



DECLARE @output table
(
id int identity(1,1),
Policy_number varchar(30),
Actual decimal(15,1),
Modified decimal(15,2)
)


select * from @temp

SET @loop = 1
SELECT @rows = count(1) from @temp	
	
While (@loop <= @rows)
BEGIN

SET @policy  = null
SET @diff  = null
SET @totalrows = null
SET @updatevalue = null

SELECT @policy = Policy_number,@diff = OutExpensesDiff from @temp where sno =@loop

select @totalrows = Count(1)  from W_DM_QER where policy_number = @policy and ASL_Code=@ASL --and transaction_identifier = @Trans_Id 

Select @updatevalue = convert(decimal(15,2),@diff) --/ @totalrows

Insert into @output
SELECT policy_number, Written_Premium, Written_Premium - @updatevalue
from W_DM_QER where policy_number = @policy and ASL_Code=@ASL --and transaction_identifier = @Trans_Id 
	and Written_Premium  = (select MAX(Written_Premium) from W_DM_QER
					where policy_number = @policy and ASL_Code=@ASL) --and Transaction_Identifier=@Trans_Id and Loss_Amount<>0)

update top(1) W_DM_QER set  Written_Premium=Written_Premium - @updatevalue
 where policy_number = @policy and ASL_Code=@ASL --and transaction_identifier = @Trans_Id 
	and Written_Premium  = (select MAX(Written_Premium) from W_DM_QER
					where policy_number = @policy and ASL_Code=@ASL) --and Transaction_Identifier=@Trans_Id and Loss_Amount<>0)

SET @loop = @loop + 1

END	


select * from @output
